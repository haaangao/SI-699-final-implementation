import * as React from 'react'
import { PropertyControls, ControlType } from 'framer'
import * as Tuna from 'tunajs'
import { frequencyTitles, frequencyValues } from './frequencies'

interface Window {
  AudioContext: any
  webkitAudioContext?: any
  setTimeout: any
}
declare var window: Window

const createAudioContext = () => {
  if (typeof window === 'undefined') {
    return undefined
  }

  const AudioContext = window.AudioContext || window.webkitAudioContext
  const ctx = new AudioContext()
  if (AudioContext) {
    return ctx
  }

  return undefined
}

const waveForms = ['sine', 'square', 'sawtooth', 'triangle']

interface Props {
  onStop: VoidFunction
  audioContext: AudioContext
  attack: number
  volume: number
  frequency: number
  bgColor: string
  wave: OscillatorType
  chorus: boolean
  overdrive: boolean
}
export class SynthButton extends React.Component<Props> {
  gainNode: GainNode
  oscillator: OscillatorNode
  randId: number
  tuna: any | null
  setToZeroTimeout: number | null
  static defaultProps = {
    attack: 50,
    audioContext: createAudioContext(),
    frequency: '16.35',
    bgColor: 'rgba(0,0,0,0.5)',
    volume: 50,
    wave: 'square',
    chorus: false,
    overdrive: false
  }

  static propertyControls: PropertyControls<Props> = {
    wave: {
      type: ControlType.Enum,
      options: waveForms,
      optionTitles: waveForms,
      title: 'Waveform'
    },
    frequency: {
      type: ControlType.Enum,
      options: frequencyValues,
      optionTitles: frequencyTitles,
      title: 'Frequency'
    },
    volume: {
      type: ControlType.Number,
      min: 1,
      max: 100,
      title: 'Volume'
    },
    attack: {
      type: ControlType.Number,
      min: 1,
      max: 100,
      title: 'attack'
    },
    bgColor: { type: ControlType.Color, title: 'Background' },
    chorus: {
      type: ControlType.Boolean,
      title: 'Chorus'
    },
    overdrive: {
      type: ControlType.Boolean,
      title: 'overdrive'
    }
  }

  componentDidMount() {
    this.randId = Math.random()
    this.initializeNodes()
  }

  componentDidUpdate(prevProps) {
    if (this.gainNode && prevProps.volume !== this.props.volume) {
      this.gainNode.gain.value = this.props.volume / 100
    }

    if (prevProps.chorus !== this.props.chorus && this.gainNode) {
      this.gainNode.disconnect()
      this.connectNodes()
    }
  }

  componentWillUnmount() {
    if (this.oscillator) {
      this.oscillator.stop(0)
    }
  }

  playSound = () => {
    const { audioContext, frequency, volume } = this.props
    if (this.setToZeroTimeout !== null) {
      clearTimeout(this.setToZeroTimeout)
    }
    this.gainNode.gain.cancelScheduledValues(audioContext.currentTime)
    this.gainNode.gain.setValueAtTime(0.0001, audioContext.currentTime) // exponentialRampToValueAtTime does not like 0 so we set it to almost zero here
    this.gainNode.gain.exponentialRampToValueAtTime(
      volume,
      audioContext.currentTime + this.props.attack
    )
  }

  stopSound = () => {
    const { audioContext, frequency, volume } = this.props
    this.gainNode.gain.cancelScheduledValues(audioContext.currentTime)
    this.gainNode.gain.setTargetAtTime(0, audioContext.currentTime, 0.2)
  }

  initializeNodes = () => {
    const { audioContext, volume, frequency } = this.props
    if (audioContext) {
      this.gainNode = audioContext.createGain()
      this.gainNode.gain.value = 0 // Begin at zero

      this.oscillator = audioContext.createOscillator()
      this.oscillator.frequency.value = frequency
      this.oscillator.type = this.props.wave
      this.oscillator.start(0)
      this.oscillator.connect(this.gainNode)

      this.tuna = new Tuna(audioContext)
      this.connectNodes()
    }
  }

  connectNodes = () => {
    const { audioContext } = this.props
    if (audioContext && this.tuna) {
      const tuna = this.tuna

      if (this.props.chorus) {
        const chorus = new tuna.Chorus({
          feedback: 0.4, //[0,0.95]
          delay: 0.05, //[0,1],
          depth: 0.1, //[0,1]
          rate: 3.1, //[0,8]
          bypass: 0
        })
        this.gainNode.connect(chorus)
        chorus.connect(audioContext.destination)
      }
      if (this.props.overdrive) {
        const overdrive = new tuna.Overdrive({
          outputGain: 0.5, //0 to 1+
          drive: 0.1, //0 to 1
          curveAmount: 0.1, //0 to 1
          algorithmIndex: 1, //0 to 5, selects one of our drive algorithms
          bypass: 1
        })
        this.gainNode.connect(overdrive)
        overdrive.connect(audioContext.destination)
      }

      if (!this.props.overdrive && !this.props.chorus) {
        this.gainNode.connect(audioContext.destination)
      }
    }
  }

  render() {
    return (
      <div
        onMouseDown={this.playSound}
        onMouseUp={this.stopSound}
        onMouseOut={this.stopSound}
        // onTouchStart={this.playSound}
        // onTouchEnd={this.stopSound}
        style={{
          background: this.props.bgColor,
          borderRadius: '6px',
          width: '100%',
          height: '100%'
        }}
      />
    )
  }
}
