// WARNING: this file is auto generated, any changes will be lost
import { createDesignComponent, CanvasStore } from "framer"
const canvas = CanvasStore.shared(); // CANVAS_DATA;
export const Example = createDesignComponent<{parentSize?:{width:number,height:number},width?:number,height?:number}>(canvas, "id_SIAkvuRQF", {}, 375,812);
