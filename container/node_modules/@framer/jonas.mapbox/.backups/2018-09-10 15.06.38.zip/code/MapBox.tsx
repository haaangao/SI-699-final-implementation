import * as React from "react";
import ReactMapGL from "react-map-gl";
import { PropertyControls, ControlType } from "framer";

enum LocationType {
  City = "City",
  Custom = "Custom"
}

interface Props {
  width: number;
  height: number;
  style: string;
  customStyle: string;
  locationType: LocationType;
  city: string;
  latitude: number;
  longitude: number;
  zoom: number;
  accessToken: string;
}

interface State {
  previousWidth: number;
  previousHeight: number;
  previousLatitude: number;
  previousLongitude: number;
  previousZoom: number;
  viewport: {
    width: number;
    height: number;
    latitude: number;
    longitude: number;
    zoom: number;
  };
}

const mapStyles = {
  Dark: "mapbox://styles/jonastreub/cill5956x0078c6m2z4vmhtli",
  Light: "mapbox://styles/jonastreub/cjjqxqloo0zp22sqv7yb61sb5",
  Street: "mapbox://styles/mapbox/streets-v10",
  Satellite: "mapbox://styles/jonastreub/cjjqxrg0b0qzx2smrc60dty3m",
  Terrain: "mapbox://styles/jonastreub/cjjqxsb9h0zq32sqqz5fts0le",
  Cartoon: "mapbox://styles/jonastreub/cjjqy9x1n0h3s2rr459bpykxj",
  Odyssey: "mapbox://styles/jonastreub/cjjqxtic40miz2rl6e8newueb",
  Shine: "mapbox://styles/jonastreub/cjjqxhmm10t8v2slgoeaqt7mm"
};

const mapStyleTitles = Object.keys(mapStyles);
const mapStyleValues = mapStyleTitles.map(title => mapStyles[title]);

const defaultToken =
  "pk.eyJ1Ijoiam9uYXN0cmV1YiIsImEiOiJjOWVVOGNBIn0.MLm-FmYDC4KT20ArnYojxQ";

export class MapBox extends React.Component<Props, State> {
  static defaultProps: Partial<Props> = {
    width: 375,
    height: 375,
    style: mapStyles.Dark,
    locationType: LocationType.City,
    city: "Amsterdam",
    latitude: 52.375,
    longitude: 4.9,
    zoom: 12
  };

  static propertyControls: PropertyControls<Props> = {
    style: {
      type: ControlType.Enum,
      options: mapStyleValues,
      optionTitles: mapStyleTitles,
      title: "Style"
    },
    customStyle: {
      type: ControlType.String,
      title: "CustomStyle"
    },
    locationType: {
      type: ControlType.SegmentedEnum,
      options: [LocationType.City, LocationType.Custom],
      title: "Location"
    },
    city: {
      type: ControlType.Enum,
      options: cities
    },
    latitude: {
      type: ControlType.Number,
      min: -90,
      max: 90,
      step: 0.0001,
      title: "Latitude"
    },
    longitude: {
      type: ControlType.Number,
      min: -180,
      max: 180,
      step: 0.0001,
      title: "Longitude"
    },
    zoom: {
      type: ControlType.Number,
      min: 0,
      max: 16,
      title: "Zoom",
      step: 0.1
    },
    accessToken: { type: ControlType.String, title: "Token" }
  };

  state: State = {
    previousWidth: MapBox.defaultProps.width,
    previousHeight: MapBox.defaultProps.height,
    previousLatitude: MapBox.defaultProps.latitude,
    previousLongitude: MapBox.defaultProps.longitude,
    previousZoom: MapBox.defaultProps.zoom,
    viewport: {
      width: MapBox.defaultProps.width,
      height: MapBox.defaultProps.height,
      latitude: MapBox.defaultProps.latitude,
      longitude: MapBox.defaultProps.longitude,
      zoom: MapBox.defaultProps.zoom
    }
  };

  static getDerivedStateFromProps(
    props: Props,
    previousState: State
  ): State | null {
    let newState: State | null = null;

    if (previousState.previousWidth !== props.width) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousWidth = props.width;
      newState.viewport.width = props.width;
    }

    if (previousState.previousHeight !== props.height) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousHeight = props.height;
      newState.viewport.height = props.height;
    }

    if (previousState.previousLatitude !== props.latitude) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousLatitude = props.latitude;
      newState.viewport.latitude = props.latitude;
    }

    if (previousState.previousLongitude !== props.longitude) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousLongitude = props.longitude;
      newState.viewport.longitude = props.longitude;
    }

    if (previousState.previousZoom !== props.zoom) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousZoom = props.zoom;
      newState.viewport.zoom = props.zoom;
    }

    return newState;
  }

  render() {
    const { accessToken, style, customStyle } = this.props;
    return (
      <ReactMapGL
        mapStyle={customStyle || style}
        mapboxApiAccessToken={accessToken || defaultToken}
        {...this.state.viewport}
        onViewportChange={viewport => this.setState({ viewport })}
      />
    );
  }
}

const cityCoordinates = {
  "Andorra la Vella": { latitude: 42.50779, longitude: 1.52109 },
  "Abu Dhabi": { latitude: 24.46667, longitude: 54.36667 },
  Kabul: { latitude: 34.52813, longitude: 69.17233 },
  "St. John's": { latitude: 47.56494, longitude: -52.70931 },
  "The Valley": { latitude: 18.21704, longitude: -63.05783 },
  Tirana: { latitude: 41.3275, longitude: 19.81889 },
  Yerevan: { latitude: 40.18111, longitude: 44.51361 },
  Willemstad: { latitude: 12.1084, longitude: -68.93354 },
  Luanda: { latitude: -8.8368, longitude: 13.23317 },
  "Buenos Aires": { latitude: -34.61315, longitude: -58.37723 },
  "Pago Pago": { latitude: -14.27806, longitude: -170.7025 },
  Vienna: { latitude: 38.90122, longitude: -77.26526 },
  Canberra: { latitude: -35.28346, longitude: 149.12807 },
  Oranjestad: { latitude: 12.52398, longitude: -70.02703 },
  Mariehamn: { latitude: 60.09726, longitude: 19.93481 },
  Baku: { latitude: 40.37767, longitude: 49.89201 },
  Sarajevo: { latitude: 43.84864, longitude: 18.35644 },
  Bridgetown: { latitude: 13.1, longitude: -59.61667 },
  Dhaka: { latitude: 26.68333, longitude: 85.16667 },
  Brussels: { latitude: 50.85045, longitude: 4.34878 },
  Ouagadougou: { latitude: 12.36423, longitude: -1.53834 },
  Sofia: { latitude: 42.69751, longitude: 23.32415 },
  Manama: { latitude: 26.21536, longitude: 50.5832 },
  Bujumbura: { latitude: -3.3822, longitude: 29.3644 },
  "Porto-Novo": { latitude: 6.49646, longitude: 2.60359 },
  Gustavia: { latitude: 17.89618, longitude: -62.84978 },
  Hamilton: { latitude: 39.3995, longitude: -84.56134 },
  "Bandar Seri Begawan": { latitude: 4.94029, longitude: 114.94806 },
  "La Paz": { latitude: -34.76167, longitude: -56.22361 },
  Brasilia: { latitude: -15.77972, longitude: -47.92972 },
  Nassau: { latitude: 25.05823, longitude: -77.34306 },
  Thimphu: { latitude: 27.46609, longitude: 89.64191 },
  Gaborone: { latitude: -24.65451, longitude: 25.90859 },
  Minsk: { latitude: 53.9, longitude: 27.56667 },
  Belmopan: { latitude: 17.25, longitude: -88.76667 },
  Ottawa: { latitude: 41.34559, longitude: -88.84258 },
  "West Island": { latitude: -12.15681, longitude: 96.82251 },
  Kinshasa: { latitude: -4.32459, longitude: 15.32146 },
  Bangui: { latitude: 4.36122, longitude: 18.55496 },
  Brazzaville: { latitude: -4.2669, longitude: 15.28327 },
  Bern: { latitude: 46.94809, longitude: 7.44744 },
  Yamoussoukro: { latitude: 6.81667, longitude: -5.28333 },
  Avarua: { latitude: -21.20778, longitude: -159.775 },
  Santiago: { latitude: 16.68808, longitude: 121.5487 },
  Yaounde: { latitude: 3.86667, longitude: 11.51667 },
  Beijing: { latitude: 39.9075, longitude: 116.39723 },
  Bogota: { latitude: 4.60971, longitude: -74.08175 },
  "San Jose": { latitude: 10.95173, longitude: -85.1361 },
  Belgrade: { latitude: 44.80401, longitude: 20.46513 },
  Havana: { latitude: 23.13302, longitude: -82.38304 },
  Praia: { latitude: 14.92148, longitude: -23.50868 },
  "Flying Fish Cove": { latitude: -10.42172, longitude: 105.67912 },
  Nicosia: { latitude: 35.16667, longitude: 33.36667 },
  Prague: { latitude: 50.08804, longitude: 14.42076 },
  Berlin: { latitude: 52.52437, longitude: 13.41053 },
  Djibouti: { latitude: 11.58767, longitude: 43.14468 },
  Copenhagen: { latitude: 55.67594, longitude: 12.56553 },
  Roseau: { latitude: 15.30174, longitude: -61.38808 },
  "Santo Domingo": { latitude: 18.50012, longitude: -69.98857 },
  Algiers: { latitude: 36.7525, longitude: 3.04197 },
  Quito: { latitude: -0.22985, longitude: -78.52495 },
  Tallinn: { latitude: 59.43696, longitude: 24.75353 },
  Cairo: { latitude: 30.06263, longitude: 31.24967 },
  "El-Aaiun": { latitude: 27.16224, longitude: -13.20315 },
  Asmara: { latitude: 15.33333, longitude: 38.93333 },
  Madrid: { latitude: 40.4165, longitude: -3.70256 },
  "Addis Ababa": { latitude: 9.02497, longitude: 38.74689 },
  Helsinki: { latitude: 60.16952, longitude: 24.93545 },
  Suva: { latitude: -18.14161, longitude: 178.44149 },
  Stanley: { latitude: -51.7, longitude: -57.85 },
  Palikir: { latitude: 6.92477, longitude: 158.16109 },
  Torshavn: { latitude: 62.00973, longitude: -6.77164 },
  Paris: { latitude: 33.66094, longitude: -95.55551 },
  Libreville: { latitude: 0.38333, longitude: 9.45 },
  London: { latitude: 51.50853, longitude: -0.12574 },
  "St. George's": { latitude: 12.05644, longitude: -61.74849 },
  Tbilisi: { latitude: 41.69411, longitude: 44.83368 },
  Cayenne: { latitude: 4.93333, longitude: -52.33333 },
  "St. Peter Port": { latitude: 49.45981, longitude: -2.53527 },
  Accra: { latitude: 5.55602, longitude: -0.1969 },
  Gibraltar: { latitude: 36.14474, longitude: -5.35257 },
  Nuuk: { latitude: 64.18347, longitude: -51.72157 },
  Banjul: { latitude: 13.45274, longitude: -16.57803 },
  Conakry: { latitude: 9.53795, longitude: -13.67729 },
  "Basse-Terre": { latitude: 15.99854, longitude: -61.72548 },
  Malabo: { latitude: 3.75, longitude: 8.78333 },
  Athens: { latitude: 34.80287, longitude: -86.97167 },
  Grytviken: { latitude: -54.28111, longitude: -36.5092 },
  "Guatemala City": { latitude: 14.64072, longitude: -90.51327 },
  Hagatna: { latitude: 13.47417, longitude: 144.74778 },
  Bissau: { latitude: 28.25, longitude: 75.08333 },
  Georgetown: { latitude: 30.63269, longitude: -97.67723 },
  "Hong Kong": { latitude: 22.28552, longitude: 114.15769 },
  Tegucigalpa: { latitude: 14.0818, longitude: -87.20681 },
  Zagreb: { latitude: 45.81444, longitude: 15.97798 },
  "Port-au-Prince": { latitude: 18.53917, longitude: -72.335 },
  Budapest: { latitude: 47.49801, longitude: 19.03991 },
  Jakarta: { latitude: -6.21462, longitude: 106.84513 },
  Dublin: { latitude: 37.70215, longitude: -121.93579 },
  Jerusalem: { latitude: 31.77902, longitude: 35.2253 },
  "Douglas, Isle of Man": { latitude: 54.15, longitude: -4.48333 },
  "New Delhi": { latitude: 28.63576, longitude: 77.22445 },
  "Diego Garcia": { latitude: -7.3, longitude: 72.4 },
  Baghdad: { latitude: 33.34058, longitude: 44.40088 },
  Tehran: { latitude: 35.69439, longitude: 51.42151 },
  Reykjavik: { latitude: 64.13548, longitude: -21.89541 },
  Rome: { latitude: 43.21285, longitude: -75.45573 },
  "Saint Helier": { latitude: 49.18333, longitude: -2.1 },
  Amman: { latitude: 31.95522, longitude: 35.94503 },
  Tokyo: { latitude: 35.61488, longitude: 139.5813 },
  Nairobi: { latitude: -1.28333, longitude: 36.81667 },
  Bishkek: { latitude: 42.87, longitude: 74.59 },
  "Phnom Penh": { latitude: 11.56245, longitude: 104.91601 },
  Tarawa: { latitude: 1.3278, longitude: 172.97696 },
  Moroni: { latitude: -11.70216, longitude: 43.25506 },
  Basseterre: { latitude: 17.29484, longitude: -62.7261 },
  Pyongyang: { latitude: 39.03385, longitude: 125.75432 },
  Seoul: { latitude: 37.56826, longitude: 126.97783 },
  "Kuwait City": { latitude: 29.36972, longitude: 47.97833 },
  "George Town": { latitude: 5.41123, longitude: 100.33543 },
  Astana: { latitude: 51.1801, longitude: 71.44598 },
  Vientiane: { latitude: 17.96667, longitude: 102.6 },
  Beirut: { latitude: 33.88894, longitude: 35.49442 },
  Castries: { latitude: 13.9957, longitude: -61.00614 },
  Vaduz: { latitude: 47.14151, longitude: 9.52154 },
  Colombo: { latitude: 6.93194, longitude: 79.84778 },
  Monrovia: { latitude: 34.14806, longitude: -117.99895 },
  Maseru: { latitude: -29.31667, longitude: 27.48333 },
  Vilnius: { latitude: 54.68916, longitude: 25.2798 },
  Luxembourg: { latitude: 49.61167, longitude: 6.13 },
  Riga: { latitude: 56.946, longitude: 24.10589 },
  Tripolis: { latitude: 37.50889, longitude: 22.37944 },
  Rabat: { latitude: 34.01325, longitude: -6.83255 },
  Monaco: { latitude: 43.73333, longitude: 7.41667 },
  Chisinau: { latitude: 47.00556, longitude: 28.8575 },
  Podgorica: { latitude: 42.44111, longitude: 19.26361 },
  Marigot: { latitude: 18.06667, longitude: -63.08333 },
  Antananarivo: { latitude: -18.91433, longitude: 47.53098 },
  Majuro: { latitude: 7.08971, longitude: 171.38027 },
  Skopje: { latitude: 42, longitude: 21.43333 },
  Bamako: { latitude: 12.65, longitude: -8 },
  "Nay Pyi Taw": { latitude: 19.745, longitude: 96.12972 },
  Ulaanbaatar: { latitude: 47.90771, longitude: 106.88324 },
  Macao: { latitude: 22.20056, longitude: 113.54611 },
  Saipan: { latitude: 15.21233, longitude: 145.7545 },
  "Fort-de-France": { latitude: 14.60892, longitude: -61.07334 },
  Nouakchott: { latitude: 18.10033, longitude: -15.94975 },
  Plymouth: { latitude: 45.01052, longitude: -93.45551 },
  Valletta: { latitude: 35.89972, longitude: 14.51472 },
  "Port Louis": { latitude: -20.16194, longitude: 57.49889 },
  Male: { latitude: 4.1748, longitude: 73.50888 },
  Lilongwe: { latitude: -13.98333, longitude: 33.78333 },
  "Mexico City": { latitude: 19.42847, longitude: -99.12766 },
  "Kuala Lumpur": { latitude: 3.1412, longitude: 101.68653 },
  Maputo: { latitude: -25.96528, longitude: 32.58917 },
  Windhoek: { latitude: -22.55941, longitude: 17.08323 },
  Noumea: { latitude: -22.27631, longitude: 166.4572 },
  Niamey: { latitude: 13.5125, longitude: 2.11178 },
  Kingston: { latitude: 41.92704, longitude: -73.99736 },
  Abuja: { latitude: 9.05735, longitude: 7.48976 },
  Managua: { latitude: 12.13282, longitude: -86.2504 },
  Amsterdam: { latitude: 42.93869, longitude: -74.18819 },
  Oslo: { latitude: 59.91273, longitude: 10.74609 },
  Kathmandu: { latitude: 27.70169, longitude: 85.3206 },
  Yaren: { latitude: -0.54756, longitude: 166.91729 },
  Alofi: { latitude: -19.05952, longitude: -169.91867 },
  Wellington: { latitude: 26.65868, longitude: -80.24144 },
  Muscat: { latitude: 23.61333, longitude: 58.59333 },
  "Panama City": { latitude: 30.15946, longitude: -85.65983 },
  Lima: { latitude: 40.74255, longitude: -84.10523 },
  Papeete: { latitude: -17.53333, longitude: -149.56667 },
  "Port Moresby": { latitude: -9.44314, longitude: 147.17972 },
  Manila: { latitude: 14.6042, longitude: 120.9822 },
  Islamabad: { latitude: 33.72148, longitude: 73.04329 },
  Warsaw: { latitude: 52.22977, longitude: 21.01178 },
  "Saint-Pierre": { latitude: -21.3393, longitude: 55.47811 },
  Adamstown: { latitude: -25.06597, longitude: -130.10147 },
  "San Juan": { latitude: 26.18924, longitude: -98.15529 },
  "East Jerusalem": { latitude: 31.78336, longitude: 35.23388 },
  Lisbon: { latitude: 38.71667, longitude: -9.13333 },
  Melekeok: { latitude: 7.50043, longitude: 134.62355 },
  Asuncion: { latitude: -25.30066, longitude: -57.63591 },
  Doha: { latitude: 25.27932, longitude: 51.52245 },
  "Saint-Denis": { latitude: -20.88231, longitude: 55.4504 },
  Bucharest: { latitude: 44.43225, longitude: 26.10626 },
  Moscow: { latitude: 46.73239, longitude: -117.00017 },
  Kigali: { latitude: -1.94995, longitude: 30.05885 },
  Riyadh: { latitude: 24.68773, longitude: 46.72185 },
  Honiara: { latitude: -9.43333, longitude: 159.95 },
  Victoria: { latitude: 28.80527, longitude: -97.0036 },
  Khartoum: { latitude: 15.54665, longitude: 32.53361 },
  Stockholm: { latitude: 59.33258, longitude: 18.0649 },
  Singapur: { latitude: 17.46972, longitude: 78.1275 },
  Jamestown: { latitude: 42.097, longitude: -79.23533 },
  Ljubljana: { latitude: 46.05108, longitude: 14.50513 },
  Longyearbyen: { latitude: 78.2186, longitude: 15.64007 },
  Bratislava: { latitude: 48.14816, longitude: 17.10674 },
  Freetown: { latitude: 8.484, longitude: -13.22994 },
  "San Marino": { latitude: 43.93333, longitude: 12.45 },
  Dakar: { latitude: 14.6937, longitude: -17.44406 },
  Mogadishu: { latitude: 2.03711, longitude: 45.34375 },
  Paramaribo: { latitude: 5.86638, longitude: -55.16682 },
  "Sao Tome": { latitude: 0.33654, longitude: 6.72732 },
  "San Salvador": { latitude: 13.68935, longitude: -89.18718 },
  Philipsburg: { latitude: 18.026, longitude: -63.04582 },
  Damascus: { latitude: 39.28844, longitude: -77.20387 },
  Mbabane: { latitude: -26.31667, longitude: 31.13333 },
  "Cockburn Town": { latitude: 21.46122, longitude: -71.14188 },
  "N'Djamena": { latitude: 12.11058, longitude: 15.03479 },
  "Port-aux-Francais": { latitude: -49.35, longitude: 70.21667 },
  Lome: { latitude: 6.13748, longitude: 1.21227 },
  Bangkok: { latitude: 13.75, longitude: 100.51667 },
  Dushanbe: { latitude: 38.53575, longitude: 68.77905 },
  Dili: { latitude: -8.55861, longitude: 125.57361 },
  Ashgabat: { latitude: 37.95, longitude: 58.38333 },
  Tunis: { latitude: 36.81897, longitude: 10.16579 },
  "Nuku'alofa": { latitude: -21.13333, longitude: -175.2 },
  Ankara: { latitude: 39.91987, longitude: 32.85427 },
  "Port of Spain": { latitude: 10.66617, longitude: -61.51657 },
  Funafuti: { latitude: -8.52425, longitude: 179.19417 },
  Taipei: { latitude: 25.04776, longitude: 121.53185 },
  Dodoma: { latitude: -6.17486, longitude: 35.73792 },
  Kiev: { latitude: 50.45466, longitude: 30.5238 },
  Kampala: { latitude: 0.31628, longitude: 32.58219 },
  Washington: { latitude: 37.13054, longitude: -113.50829 },
  Montevideo: { latitude: -34.83346, longitude: -56.16735 },
  Tashkent: { latitude: 41.26465, longitude: 69.21627 },
  "Vatican City": { latitude: 41.90236, longitude: 12.45332 },
  Kingstown: { latitude: 13.15872, longitude: -61.22475 },
  Caracas: { latitude: 10.5, longitude: -66.91667 },
  "Road Town": { latitude: 18.41667, longitude: -64.61667 },
  "Charlotte Amalie": { latitude: 18.3419, longitude: -64.9307 },
  Hanoi: { latitude: 21.0245, longitude: 105.84117 },
  "Port Vila": { latitude: -17.73381, longitude: 168.32188 },
  "Mata-Utu": { latitude: -13.28163, longitude: -176.17453 },
  Apia: { latitude: -13.83333, longitude: -171.76666 },
  Pristina: { latitude: 42.67272, longitude: 21.16688 },
  Sanaa: { latitude: 15.35472, longitude: 44.20667 },
  Mamoudzou: { latitude: -12.77944, longitude: 45.22722 },
  Pretoria: { latitude: -25.74486, longitude: 28.18783 },
  Lusaka: { latitude: -15.40809, longitude: 28.28636 },
  Harare: { latitude: -17.82935, longitude: 31.05389 }
};

const cities = Object.keys(cityCoordinates).sort();
