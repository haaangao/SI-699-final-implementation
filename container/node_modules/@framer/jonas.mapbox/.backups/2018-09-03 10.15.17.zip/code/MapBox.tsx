import * as React from "react";
import ReactMapGL from "react-map-gl";
import { PropertyControls, ControlType } from "framer";

interface Props {
  width: number;
  height: number;
  style: string;
  customStyle: string;
  latitude: number;
  longitude: number;
  zoom: number;
  accessToken: string;
}

interface State {
  previousWidth: number;
  previousHeight: number;
  previousLatitude: number;
  previousLongitude: number;
  previousZoom: number;
  viewport: {
    width: number;
    height: number;
    latitude: number;
    longitude: number;
    zoom: number;
  };
}

const mapStyles = {
  Dark: "mapbox://styles/jonastreub/cill5956x0078c6m2z4vmhtli",
  Light: "mapbox://styles/jonastreub/cjjqxqloo0zp22sqv7yb61sb5",
  Street: "mapbox://styles/mapbox/streets-v10",
  Satellite: "mapbox://styles/jonastreub/cjjqxrg0b0qzx2smrc60dty3m",
  Terrain: "mapbox://styles/jonastreub/cjjqxsb9h0zq32sqqz5fts0le",
  Cartoon: "mapbox://styles/jonastreub/cjjqy9x1n0h3s2rr459bpykxj",
  Odyssey: "mapbox://styles/jonastreub/cjjqxtic40miz2rl6e8newueb",
  Shine: "mapbox://styles/jonastreub/cjjqxhmm10t8v2slgoeaqt7mm"
};

const mapStyleTitles = Object.keys(mapStyles);
const mapStyleValues = mapStyleTitles.map(title => mapStyles[title]);

const defaultToken =
  "pk.eyJ1Ijoiam9uYXN0cmV1YiIsImEiOiJjOWVVOGNBIn0.MLm-FmYDC4KT20ArnYojxQ";

export class MapBox extends React.Component<Props, State> {
  static defaultProps = {
    width: 375,
    height: 375,
    style: mapStyles.Dark,
    latitude: 52.375,
    longitude: 4.9,
    zoom: 12
  };

  static propertyControls: PropertyControls<Props> = {
    style: {
      type: ControlType.Enum,
      options: mapStyleValues,
      optionTitles: mapStyleTitles,
      title: "Style"
    },
    customStyle: {
      type: ControlType.String,
      title: "CustomStyle"
    },
    latitude: {
      type: ControlType.Number,
      min: -90,
      max: 90,
      title: "Latitude"
    },
    longitude: {
      type: ControlType.Number,
      min: -180,
      max: 180,
      title: "Longitude"
    },
    zoom: { type: ControlType.Number, min: 0, max: 16, title: "Zoom" },
    accessToken: { type: ControlType.String, title: "Token" }
  };

  state: State = {
    previousWidth: MapBox.defaultProps.width,
    previousHeight: MapBox.defaultProps.height,
    previousLatitude: MapBox.defaultProps.latitude,
    previousLongitude: MapBox.defaultProps.longitude,
    previousZoom: MapBox.defaultProps.zoom,
    viewport: {
      width: MapBox.defaultProps.width,
      height: MapBox.defaultProps.height,
      latitude: MapBox.defaultProps.latitude,
      longitude: MapBox.defaultProps.longitude,
      zoom: MapBox.defaultProps.zoom
    }
  };

  static getDerivedStateFromProps(
    props: Props,
    previousState: State
  ): State | null {
    let newState: State | null = null;

    if (previousState.previousWidth !== props.width) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousWidth = props.width;
      newState.viewport.width = props.width;
    }

    if (previousState.previousHeight !== props.height) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousHeight = props.height;
      newState.viewport.height = props.height;
    }

    if (previousState.previousLatitude !== props.latitude) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousLatitude = props.latitude;
      newState.viewport.latitude = props.latitude;
    }

    if (previousState.previousLongitude !== props.longitude) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousLongitude = props.longitude;
      newState.viewport.longitude = props.longitude;
    }

    if (previousState.previousZoom !== props.zoom) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousZoom = props.zoom;
      newState.viewport.zoom = props.zoom;
    }

    return newState;
  }

  render() {
    const { accessToken, style, customStyle } = this.props;
    return (
      <ReactMapGL
        mapStyle={customStyle || style}
        mapboxApiAccessToken={accessToken || defaultToken}
        {...this.state.viewport}
        onViewportChange={viewport => this.setState({ viewport })}
      />
    );
  }
}
