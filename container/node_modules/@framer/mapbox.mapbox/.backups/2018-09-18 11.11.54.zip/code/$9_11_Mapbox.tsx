import * as React from "react";
import ReactMapGL from "react-map-gl";
import { PropertyControls, ControlType } from "framer";

const cityCoordinates = {
    "Amsterdam, Netherlands": { latitude: 52.370216, longitude: 4.895168 },
    "Austin, USA": { latitude: 30.267153, longitude: -97.743057 },
    "Barcelona, Spain": { latitude: 41.385063, longitude: 2.173404 },
    "Beijing, China": { latitude: 39.904202, longitude: 116.407394 },
    "Chicago, USA": { latitude: 41.878113, longitude: -87.629799 },
    "Detroit, USA": { latitude: 42.331429, longitude: -83.045753 },
    "Dubai, UAE": { latitude: 25.204849, longitude: 55.270782 },
    "Helsinki, Findland": { latitude: 60.169857, longitude: 24.938379 },
    "Hong Kong, China": { latitude: 22.280308, longitude: 114.177007 },
    "Las Vegas, USA": { latitude: 36.169941, longitude: -115.139832 },
    "London, United Kingdom": { latitude: 51.507351, longitude: -0.127758 },
    "Los Angles, USA": { latitude: 34.052235, longitude: -118.243683 },
    "New York City, USA": { latitude: 40.712776, longitude: -74.005974 },
    "Paris, France, USA": { latitude: 48.856613, longitude: 2.352222 },
    "Portland, USA": { latitude: 45.512230, longitude: -122.658722 },
    "Rome, Italy": { latitude: 41.902782, longitude: 12.496365 },
    "San Francisco, USA": { latitude: 37.774929, longitude: -122.419418 },
    "Seattle, USA": { latitude: 47.606209, longitude: -122.332069 },
    "Shanghai, China": { latitude: 31.230391, longitude: 121.473701 },
    "Singapore": { latitude: 1.284310, longitude: 103.869666 },
    "Sydney, Australia": { latitude: -33.872760, longitude: 151.205340 },
    "Tokyo, Japan": { latitude: 35.687427, longitude: 139.786879 },
    "Vienna, Austria": { latitude: 48.208176, longitude: 16.373819 },
    "Washington DC, USA": { latitude: 38.893, longitude: -77.032 },
  }

const cities = Object.keys(cityCoordinates).sort();

enum LocationType {
  City = "City",
  Custom = "Custom"
}

interface Props {
  width: number;
  height: number;
  style: string;
  customStyle: string;
  locationType: LocationType;
  city: string;
  latitude: number;
  longitude: number;
  zoom: number;
  accessToken: string;
}

interface State {
  previousWidth: number;
  previousHeight: number;
  previousCity: string;
  previousLatitude: number;
  previousLongitude: number;
  previousZoom: number;
  viewport: {
    width: number;
    height: number;
    latitude: number;
    longitude: number;
    zoom: number;
  };
}

const mapStyles = {
    Custom: "custom",
    LabelMaker: "mapbox://styles/mapbox/cje59h2m22g4x2sjzbsv1lc42",
    LeShine: "mapbox://styles/mapbox/cjcunv5ae262f2sm9tfwg8i0w",
    MapboxDark: "mapbox://styles/mapbox/dark-v9",
    MapboxLight: "mapbox://styles/mapbox/light-v9",
    MapboxOutdoors: "mapbox://styles/mapbox/outdoors-v10",
    MapboxSatellite: "mapbox://styles/mapbox/satellite-v9",
    MapboxSatelliteStreets: "mapbox://styles/mapbox/satellite-streets-v10",
    MapboxStreets: "mapbox://styles/mapbox/streets-v10",
    Moonlight: "mapbox://styles/mapbox/cj3kbeqzo00022smj7akz3o1e",
    NorthStar: "mapbox://styles/mapbox/cj44mfrt20f082snokim4ungi",
    Scenic: "mapbox://styles/mapbox/cj8gg22et19ot2rnz65958fkn",
    Standard: "mapbox://styles/mapbox/cj4k8wmwy5lbt2smsigkbh18e",
    Terminal: "mapbox://styles/mapbox/cj62n87yx3mvi2rp93sfp2w9z",
    LATerrain: "mapbox://styles/mapbox/cjerxnqt3cgvp2rmyuxbeqme7",
    Vintage: "mapbox://styles/mapbox/cj7at0rnp9ei22rtegvjf58dx",
    Whaam: "mapbox://styles/mapbox/cj5banmps1bqr2rqwsy5aeijw",
  };

const mapStyleTitles = Object.keys(mapStyles);
const mapStyleValues = mapStyleTitles.map(title => mapStyles[title]);

const defaultToken =
/* Change below to your Mapbox acccount's access token. Get Mapbox account here: https://goo.gl/mr8X4i */
  "pk.eyJ1IjoibXNsZWUiLCJhIjoiY2psdnB6cXN0MHd3bjNwb2R6bWFtbmg4eSJ9.DMA9TUmO4G_vDIkb6RDtZA";

export class Mapbox extends React.Component<Props, State> {
  static defaultProps: Partial<Props> = {
    width: 375,
    height: 375,
    style: mapStyles.MapboxLight,
    locationType: LocationType.City,
    city: "Amsterdam",
    latitude: 52.375,
    longitude: 4.9,
    zoom: 12
  };

  static propertyControls: PropertyControls<Props> = {
    accessToken: { type: ControlType.String, title: "AccessToken" },
    style: {
      type: ControlType.Enum,
      options: mapStyleValues,
      optionTitles: mapStyleTitles,
      title: "Map Style"
    },
    customStyle: {
      type: ControlType.String,
      title: " ",
      placeholder: "mapbox://styles/<youraccountID>/<mapstyleID>",
      hidden(props) {
        return props.style !== "custom";
      }
    },
    locationType: {
      type: ControlType.SegmentedEnum,
      options: [LocationType.City, LocationType.Custom],
      title: "Location"
    },
    city: {
      type: ControlType.Enum,
      options: cities,
      title: "City",
      hidden(props) {
        console.log(props);

        return props.locationType === LocationType.Custom;
      }
    },
    latitude: {
      type: ControlType.Number,
      min: -90,
      max: 90,
      step: 0.0001,
      title: "Latitude",
      hidden(props) {
        return props.locationType === LocationType.City;
      }
    },
    longitude: {
      type: ControlType.Number,
      min: -180,
      max: 180,
      step: 0.0001,
      title: "Longitude",
      hidden(props) {
        return props.locationType === LocationType.City;
      }
    },
    zoom: {
      type: ControlType.Number,
      min: 0,
      max: 16,
      title: "Zoom",
      step: 0.1
    }
  };

  state: State = {
    previousWidth: Mapbox.defaultProps.width,
    previousHeight: Mapbox.defaultProps.height,
    previousCity: Mapbox.defaultProps.city,
    previousLatitude: Mapbox.defaultProps.latitude,
    previousLongitude: Mapbox.defaultProps.longitude,
    previousZoom: Mapbox.defaultProps.zoom,
    viewport: {
      width: Mapbox.defaultProps.width,
      height: Mapbox.defaultProps.height,
      latitude: Mapbox.defaultProps.latitude,
      longitude: Mapbox.defaultProps.longitude,
      zoom: Mapbox.defaultProps.zoom
    }
  };

  static getDerivedStateFromProps(
    props: Props,
    previousState: State
  ): State | null {
    let newState: State | null = null;

    if (previousState.previousWidth !== props.width) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousWidth = props.width;
      newState.viewport.width = props.width;
    }

    if (previousState.previousHeight !== props.height) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousHeight = props.height;
      newState.viewport.height = props.height;
    }

    let { latitude, longitude } = props;

    if (props.locationType === LocationType.City) {
      const coordinates = cityCoordinates[props.city];
      if (coordinates) {
        latitude = coordinates.latitude;
        longitude = coordinates.longitude;
      }
    }

    if (previousState.previousLatitude !== latitude) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousLatitude = latitude;
      newState.viewport.latitude = latitude;
    }

    if (previousState.previousLongitude !== longitude) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousLongitude = longitude;
      newState.viewport.longitude = longitude;
    }

    if (previousState.previousZoom !== props.zoom) {
      if (newState === null) {
        newState = { ...previousState };
      }
      newState.previousZoom = props.zoom;
      newState.viewport.zoom = props.zoom;
    }

    return newState;
  }

  render() {
    const { accessToken, style, customStyle } = this.props;
    return (
      <ReactMapGL
        mapStyle={customStyle || style}
        mapboxApiAccessToken={accessToken || defaultToken}
        {...this.state.viewport}
        onViewportChange={viewport => this.setState({ viewport })}
      />
    );
  }
}
