// import * as React from "react"
// import { PropertyControls, ControlType } from "framer"
// import styled, { css } from "styled-components"

// const StyledButton = styled.button`
//   width: 305px;
//   height: 54px;
//   padding: 15px;
//   border-radius: 4px;
//   font-size: 16px;
//   ${props => props.type == 'primary' && css`
//     color: #ccc;
//     background-color: white;
//   `}
//   ${props => props.type == 'secondary' && css`
//     color: #ccc;
//     background-color: white;
//   `}
// `

// // Define type of property
// interface Props {
//   text: string;
//   type: string;
// }

// export class Button extends React.Component<Props> {

//   // Set default propertiess
//   static defaultProps = {
//     text: "Hello World!",
//     type: "primary",
//   }

//   // Items shown in property panel
//   static propertyControls: PropertyControls = {
//     text: { 
//       type: ControlType.String, 
//       title: "from" 
//     },
//     type: { 
//       type: ControlType.Enum, 
//       title: "from",
//       options: ['primary', 'secondary'],
//       optionTitles: ['Primary Button', 'Secondary Button'] 
//     },
//   }

//   render() {
//     return (
//       <StyledButton type={this.props.type}>
//         {this.props.text}
//       </StyledButton>
//     )
//   }
// }

import * as React from "react"
import { PropertyControls, ControlType } from "framer"

class TextInput extends React.Component {
    ...
    render() {
      return (
        <input type="text" 
          onFocus={this.handleFocus} 
          onBlur={this.handleBlur} 
        />
      )
    }
  }

export const InputEvents: Override = () => {
    return {
      onFocus() {
        // Don't move the screen up on iOS because it already moves
        // the screen for us
        !iOS && animate.ease(data.containerTop, -200, { duration: 0.2 });
      },
      onBlur() {
        !iOS && animate.ease(data.containerTop, 0, { duration: 0.2 });
      }
    };
  };